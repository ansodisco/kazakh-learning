import { useState } from 'react'
import './App.css'
import Login from './assets/Login'
import Dashboard from './assets/Dashboard'

function App() {
  const [user, setUser] = useState<string | null>(null)

  return (
    <>
      {!user ? (
        <Login onLogin={setUser} />
      ) : (
        <Dashboard username={user} />
      )}
    </>
  )
}

export default App
